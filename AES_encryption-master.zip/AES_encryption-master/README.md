This code is the hardware implementation of advanced encryption standard(AES) a.k.a rijndael, written in verilog.
